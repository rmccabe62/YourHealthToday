package com.project.virtualvote;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class VirtualvoteApplication {

	public static void main(String[] args) {
		SpringApplication.run(VirtualvoteApplication.class, args);
	}

}
